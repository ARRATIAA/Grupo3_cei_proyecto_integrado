<?php
include_once "req1.php";


$servidor="localhost";
$usuario="root";
$clave="";
$baseDeDatos="registro_brigada";

$link_conexion = mysqli_connect($servidor, $usuario, $clave,  $baseDeDatos);

if (mysqli_connect_error()){
    printf("Problemas con la Conexion %s", mysqli_connect_error());
    exit;

    return $link_conexion;
}

if(isset($_POST["Registrar"])){
   $clave=$_POST["clave"];
   $integrante=$_POST["integrante"];
   $rol=$_POST["rol"];
   $fecha=$_POST["fecha"];
   $hora_inicio=$_POST["hora_inicio"];
   $equipamiento=$_POST["equipamiento"];
   $movil_patente=$_POST["movil_patente"];
   $actividad_codigo=$_POST["actividad_codigo"];
   $unidad_clave=$_POST["unidad_clave"];

   

   $insertar = "INSERT INTO unidad_operativa Values ($clave,'$integrante','$rol' ,'$fecha','$hora_inicio','$equipamiento','$movil_patente',$actividad_codigo,$unidad_clave )";
   //echo $insertar;
   $ejecutarInsertar = mysqli_query($link_conexion, $insertar);
 }



 ?>