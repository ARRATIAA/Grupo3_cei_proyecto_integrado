<?php
include_once "dos.php";


$servidor="localhost";
$usuario="root";
$clave="";
$baseDeDatos="registro_brigada";

$link_conexion = mysqli_connect($servidor, $usuario, $clave,  $baseDeDatos);

if (mysqli_connect_error()){
    printf("Problemas con la Conexion %s", mysqli_connect_error());
    exit;

    return $link_conexion;
}

if(isset($_POST["Registrar_Datos"])){
   $rut=$_POST["rut"];
   $nombre=$_POST["nombre"];
   $fono=$_POST["fono"];
   $empresa_codigo=$_POST["empresa_codigo"];
   

   $insertar = "INSERT INTO brigadistas Values ('$rut','$nombre',$fono ,$empresa_codigo )";
   //echo $insertar;
   $ejecutarInsertar = mysqli_query($link_conexion, $insertar);
 }

//borrar los datos
 if(isset($_POST["Borrar_Datos"])){
  $rut=$_POST["rut"];
  
  $borrar = "DELETE  from brigadistas where rut='".$rut."'";
  $ejecutareliminar = mysqli_query($link_conexion, $borrar);
}


if(isset($_POST["Actualizar_Datos"])){
  $rut=$_POST["rut"];
  $nombre=$_POST["nombre"];
  $fono=$_POST["fono"];
  $empresa_codigo=$_POST["empresa_codigo"];
  

  $actualizar = "UPDATE brigadistas SET nombre = '".$nombre."', fono = ".$fono." , empresa_codigo = ".$empresa_codigo." WHERE rut = '".$rut."'";
  $ejecutareliminar = mysqli_query($link_conexion, $actualizar);
  
}



 ?>