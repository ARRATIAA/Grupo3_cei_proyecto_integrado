<?php
//iniciar la sesion
session_start();
$var='';
if(isset($_POST['bt1'])){
	//validar usuario y registrar variable de sesion
	//conectarse a la BD y extraer info del usuario
	if($_POST['n']=="nico" && $_POST['c']=="123"){
		$_SESSION['usuario']='nico';
		//echo '<a href="dos.php"> siguiente pagina</a>';
		header("Location:dos.php");
	}else{
		$var='<br><b> <p style="color:rgb(255,233,0);"> Acceso incorrecto  </b><br>';
		echo '<link rel="stylesheet" type="text/css" href="estilo.css" media="screen"/>
		    <img src="arauco.jpg" width="300">
			<body background="lo.jpg" > 

		<html>
				<head></head>
				<body>
				'.$var.'
					<form name="f1" action="uno.php" method="post">
						<td><h3>nombre:</h3><input type="text" name="n" ><br></td>
						<td><h3>clave:</h3><input type="password" name="c"><br> </td>
						<br><input type="submit" name="bt1" value="Iniciar sesion">
					</form>
				</body>
				</html>';
	}

}else{
 	echo'<html>
	<link rel="stylesheet" type="text/css" href="estilo.css" media="screen"/>
    <img src="arauco.jpg" width="300">
	<body background="lo.jpg" > 


			<head></head>
			<body>
				<form name="f1" action="uno.php" method="post">
				    <td><h3>nombre:</h3><input type="text" name="n" ><br></td>
				    <td><h3>clave:</h3> <input type="password" name="c"><br></td>
					<br>
					<input type="submit" name="bt1" value="Iniciar sesion">
				</form>
			</body>
		</html>';

}
?>