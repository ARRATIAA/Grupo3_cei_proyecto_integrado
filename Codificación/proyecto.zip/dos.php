<?php
session_start();
if(isset($_SESSION['usuario'])){
	//todo el codigo funcional ira aqui
?>
<!DOCTYPE html>


<link rel="stylesheet" type="text/css" href="estilo.css" media="screen"/>
<img src="arauco.jpg" width="300">

<td><h1>Registro</h1></td>
<html>
<head>
  <title>Formulario de registro</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <body background="lo.jpg" > 

</head>
<body >

<form method="POST" action="conexion.php" name="formulario">


<td> <h3>Cargo : Jefe de Brigada</h3></td>



<table align="center">
  <tr><td colspan="2"><h2>Registro de Brigada</h2></td></tr>
  <tr>
    <td>
    <h3> Rut: </h3>
    </td>
    <td>
      <input type="text" name="rut" required placeholder="Ingrese su RUT" >
    </td>
  </tr>

  <tr>
    <td>
    <h3> Nombre: </h3>
    </td>
    <td>
      <input type="text" name="nombre"  placeholder="Ingrese nombre completo">
    </td>
  </tr>
  
  <tr>
    <td>
    <h3> Empresa: </h3>
    </td>
    <td>
    <select type="select" name="empresa_codigo"  required placeholder value="empresa_codigo">
    <option value="1">Agesa</option>
    <option value="2">Agrifor</option>
    <option value="3">Bagaro</option>
    <option value="4">Codema</option>
    <option value="5">Arauco</option>
    </select>
    </td>
  </tr>

  <tr>
    <td>
    <h3> Telefono: </h3>
    </td>
    <td>
      <input type="number" name="fono"  placeholder="912345678">
    </td>
  </tr>

 


<tr><td colspan="2" align="center"><input type="submit" value="Registrar" name="Registrar_Datos" >

 <colspan="2" align="center"><input type="submit" value="Eliminar " name="Borrar_Datos" >

 <colspan="2" align="center"><input type="submit" value= "Actualizar"  name="Actualizar_Datos" ></td></tr>


</table>



</form>
</body>
</html>
	

	<form name="f1" action="req1.php" method="post">
		<input type="submit" name="bt1" value="Siguiente...">
	</form>
<?php
}else{
	//informes de sesión invalida

	echo 'Acceso denegado :P';
	//header("Location:uno.php");
}


?>